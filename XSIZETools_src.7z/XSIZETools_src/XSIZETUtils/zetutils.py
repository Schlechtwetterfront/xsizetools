import sys
import os
import fnmatch
from PySide import QtGui, QtCore

ZETROOT = 'up'
USERCONFIG = '\\Resources\\User\\'
MODULES = '\\Resources\\Modules\\'
POSPATH = '\\Addons\\'
VERTSPACER = 1


class ZETUtils(QtGui.QDialog):
    def __init__(self, parent=None):
        super(ZETUtils, self).__init__(parent)
        self.mwd = os.getcwd()
        self.btns = []
        self.initUI()

    def load_stylesheet(self, path):
        data = ''
        with open(path, 'r') as fh:
            data = fh.read()
        return data

    def initUI(self):
        self.setStyleSheet(self.load_stylesheet('darkorange.stylesheet'))

        self.btn_check_dir = QtGui.QPushButton('Check Dir')
        self.btns.append(self.btn_check_dir)
        self.btn_check_dir.clicked.connect(self.check_dir)

        self.btn_find_dir = QtGui.QPushButton('Find Dir')
        self.btns.append(self.btn_find_dir)
        self.btn_find_dir.clicked.connect(self.find_dir)

        self.btn_clean = QtGui.QPushButton('Clear Compiled')
        self.btns.append(self.btn_clean)
        self.btn_clean.clicked.connect(self.clean)

        self.btn_count = QtGui.QPushButton('Count Lines')
        self.btns.append(self.btn_count)
        self.btn_count.clicked.connect(self.count_lines)

        self.btn_reset = QtGui.QPushButton('Reset Config')
        self.btns.append(self.btn_reset)
        self.btn_reset.clicked.connect(self.reset_config)

        self.btn_debug = QtGui.QPushButton('Debug Info')
        self.btns.append(self.btn_debug)
        self.btn_debug.clicked.connect(self.debug_info)

        self.btn_info = QtGui.QPushButton('Info')
        self.btns.append(self.btn_info)
        self.btn_info.clicked.connect(self.print_info)

        self.btn_clear_log = QtGui.QPushButton('Clear')
        self.btns.append(self.btn_clear_log)
        self.btn_clear_log.clicked.connect(self.clear_log)

        self.btn_close = QtGui.QPushButton('Close')
        self.btns.append(self.btn_close)
        self.btn_close.clicked.connect(sys.exit)

        for btn in self.btns:
            btn.setMinimumWidth(90)
            btn.setMaximumWidth(90)

        self.log_box = QtGui.QTextEdit()
        self.log_box.setUndoRedoEnabled(False)
        self.log_box.setReadOnly(True)
        self.log_box.setWordWrapMode(QtGui.QTextOption.NoWrap)

        self.progress_bar = QtGui.QProgressBar()

        btnh0 = QtGui.QHBoxLayout()
        btnh0.addWidget(self.btn_check_dir)
        btnh0.addWidget(self.btn_find_dir)
        btnh0.addWidget(self.btn_clean)
        btnh0.addWidget(self.btn_count)
        btnh0.addWidget(self.btn_reset)

        btnh1 = QtGui.QHBoxLayout()
        btnh1.addWidget(self.btn_debug)
        btnh1.addWidget(self.btn_info)
        btnh1.addWidget(self.btn_clear_log)
        btnh1.addWidget(self.btn_close)
        btnh1.addStretch(1)

        mainv = QtGui.QVBoxLayout()
        mainv.addLayout(btnh0)
        mainv.addLayout(btnh1)
        mainv.addWidget(self.log_box)
        mainv.addWidget(self.progress_bar)

        self.setLayout(mainv)

        self.setGeometry(300, 300, 400, 600)
        self.setWindowTitle('ZETUtils')
        self.setWindowIcon(QtGui.QIcon('andeicon.png'))
        self.show()

    def log(self, text):
        self.log_box.append(text)

    def clear_log(self):
        self.log_box.clear()
        self.progress_bar.reset()

    def debug_info(self):
        self.log('<b>Application Info</B>')
        self.log(' main working dir: {0}'.format(self.mwd))
        self.log(' current dir: {0}'.format(os.getcwd()))

    def check_dir(self):
        self.log('<b>Checking current directory...</B>')
        self.progress_bar.reset()
        self.progress_bar.setMaximum(1)
        path = os.getcwd()
        self.log(' dir: {0}'.format(path))
        if 'Users' in path and 'Addons' in path:
            self.progress_bar.setValue(1)
            self.log(' valid.')
        else:
            self.progress_bar.setValue(1)
            self.log(' not valid.')
        self.log(' <i>Finished.</I>')

    def find_dir(self):
        self.progress_bar.reset()
        self.progress_bar.setMaximum(4)
        self.log('<b>Finding possible install dir...</B>')
        self.log(' current: {0}'.format(os.getcwd()))
        self.progress_bar.setValue(1)
        pospaths, invpaths = self.get_possible_install_dirs()
        self.progress_bar.setValue(2)
        for path in pospaths:
            self.log(' possible dir:')
            self.log('   {0}'.format(path))
        for path in invpaths:
            self.log(' XSI but unsupported:')
            self.log('   {0}'.format(path))
        self.progress_bar.setValue(4)
        self.log(' <i>Finished.</I>')

    def get_possible_install_dirs(self):
        user = os.environ['USERPROFILE']
        subdirs = os.listdir(user)
        possible_paths = []
        invalid_paths = []
        comps = []
        if 'Autodesk' in subdirs:
            comps.append('Autodesk')
        if 'Softimage' in subdirs:
            comps.append('Softimage')
        for comp in comps:
            comppath = os.path.join(user, comp)
            softs = os.listdir(comppath)
            for soft in softs:
                splitd = soft.split('_')
                for el in splitd:
                    try:
                        elfl = float(el)
                        if elfl > 5.11:
                            possible_paths.append(os.path.join(comppath, soft, 'Addons'))
                        else:
                            invalid_paths.append(os.path.join(comppath, soft, 'Addons'))
                    except ValueError as ve:
                        # App folders are separated with '_', ie: XSI_5.11.
                        # So I just try to covert every part of the folder to a float.
                        # There always are errors so I don't log them and just continue.
                        #self.log(str(ve))
                        continue
        return possible_paths, invalid_paths

    def clean(self):
        self.log('<b>Clearing compiled modules...</B>')
        self.progress_bar.reset()
        self.progress_bar.setMaximum(2)
        os.chdir('..')
        try:
            self.progress_bar.setValue(1)
            self.log(' root: {0}'.format(os.getcwd()))
            for path, subdirs, files in os.walk(os.getcwd()):
                for name in files:
                    if fnmatch.fnmatch(name, '*.pyc'):
                        os.remove(os.path.join(path, name))
                        self.log(' removed: {0}'.format(name))
            self.progress_bar.setValue(2)
        except IOError as ioe:
            self.log(ioe)
        os.chdir(self.mwd)
        self.log(' <i>Finished.</I>')

    def count_lines(self):
        self.progress_bar.reset()
        self.log('<B>Counting lines...</B>')
        os.chdir('..')
        self.log(' root: {0}'.format(os.getcwd()))
        mini, maxi = self.LOC(os.getcwd())
        self.log(' code lines: {0}'.format(mini))
        self.log(' total lines: {0}'.format(maxi))
        os.chdir(self.mwd)
        self.log(' <i>Finished.</I>')

    def reset_config(self):
        self.progress_bar.reset()
        self.progress_bar.setMaximum(3)
        self.log('<B>Rewriting config files...</B>')
        os.chdir('..')
        configpath = os.path.join(os.getcwd(), 'Resources', 'User')
        self.progress_bar.setValue(1)
        try:
            with open(configpath + '\\export.tcnt', 'w') as cf:
                cf.write('checksel[True]\n')
                cf.write('path[C:\]\n')
                cf.write('bbox[cube]\n')
                cf.write('overwrite[False]\n')
                cf.write('showreport[True]\n')
            self.log(' rewrote export.tcnt')
            self.progress_bar.setValue(2)
        except IOError as ioe:
            self.log(' {0}'.format(str(ioe)))
        os.chdir(self.mwd)
        self.progress_bar.setValue(3)
        self.log(' <i>Finished.</I>')

    def print_info(self):
        self.log('<b>ZETools Utilites</B>')
        self.log(' Code Copyright (C) Ande 2012')
        self.log(' https://sites.google.com/site/andescp/')
        self.log(' Qt4(PySide) pyside.org')
        self.log(' darkorange style techartists.org')

    def Walk(self, root='.', recurse=True, pattern='*'):
        """
            Generator for walking a directory tree.
            Starts at specified root folder, returning files
            that match our pattern. Optionally will also
            recurse through sub-folders.
        """
        for path, subdirs, files in os.walk(root):
            for name in files:
                if fnmatch.fnmatch(name, pattern):
                    self.progress_bar.setMaximum(self.progress_bar.maximum() + 1)
                    self.log(' file: {0}'.format(name))
                    yield os.path.join(path, name)
            if not recurse:
                break

    def LOC(self, root='', recurse=True):
        """
            Counts lines of code in two ways:
                maximal size (source LOC) with blank lines and comments
                minimal size (logical LOC) stripping same

            Sums all Python files in the specified folder.
            By default recurses through subfolders.
        """
        count_mini, count_maxi = 0, 0
        for fspec in self.Walk(root, recurse, '*.py'):
            skip = False
            for line in open(fspec).readlines():
                count_maxi += 1
                line = line.strip()
                if line:
                    if line.startswith('#'):
                        continue
                    if line.startswith('"""'):
                        skip = not skip
                        continue
                    if not skip:
                        count_mini += 1
                self.progress_bar.setValue(self.progress_bar.value() + 1)

        return count_mini, count_maxi


def main():
    app = QtGui.QApplication(sys.argv)
    utils = ZETUtils()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
